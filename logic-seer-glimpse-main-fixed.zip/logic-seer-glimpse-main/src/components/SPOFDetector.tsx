import { useState, useRef, useEffect } from 'react';
import * as d3 from 'd3';
import * as XLSX from 'xlsx';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Upload, Download, Network, AlertTriangle } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Node {
  id: string;
  x?: number;
  y?: number;
  fx?: number | null;
  fy?: number | null;
}

interface Link {
  source: string | Node;
  target: string | Node;
}

const SPOFDetector = () => {
  useEffect(() => {
    if (searchText.trim() === '') {
      setSearchResults([]);
    } else {
      const results = allNodes.filter((node) =>
        node.id.toLowerCase().includes(searchText.toLowerCase())
      );
      setSearchResults(results);
    }
  }, [searchText, allNodes]);

  const [networkData, setNetworkData] = useState<Array<Array<string>>>([]);
  const [currentSPOFs, setCurrentSPOFs] = useState<string[]>([]);
  const [allNodes, setAllNodes] = useState<Node[]>([]);
  const [allLinks, setAllLinks] = useState<Link[]>([]);
  const [searchText, setSearchText] = useState<string>('');
  const [searchResults, setSearchResults] = useState<Node[]>([]);
  const [stats, setStats] = useState<{ totalNodes: number; spofCount: number; percentage: string } | null>(null);
  
  const svgRef = useRef<SVGSVGElement>(null);
  const simulationRef = useRef<any>(null);
  
  const handleFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.name.endsWith('.xlsx')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          if (data) {
            const workbook = XLSX.read(data, { type: 'binary' });
            const sheet = workbook.Sheets['Links'];
            if (sheet) {
              const parsedData = XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1 });
              setNetworkData(parsedData);
              toast({
                title: "File Uploaded",
                description: "Your Excel file has been successfully parsed.",
              });
            } else {
              toast({
                title: "Error",
                description: "The Excel file must contain a sheet named 'Links'.",
                variant: "destructive",
              });
            }
          }
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to parse the Excel file.",
            variant: "destructive",
          });
        }
      };
      reader.readAsBinaryString(file);
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a valid Excel file (.xlsx).",
        variant: "destructive",
      });
    }
  };

  const buildGraph = (data: Array<Array<string>>) => {
    const graph: Record<string, string[]> = {};
    data.forEach(([source, target]) => {
      if (!source || !target || source === target) return;
      if (!graph[source]) graph[source] = [];
      if (!graph[target]) graph[target] = [];
      graph[source].push(target);
      graph[target].push(source);
    });
    return graph;
  };

  const findArticulationPoints = (graph: Record<string, string[]>) => {
    const visited: Record<string, boolean> = {};
    const disc: Record<string, number> = {};
    const low: Record<string, number> = {};
    const parent: Record<string, string | undefined> = {};
    const ap = new Set<string>();
    let time = 0;

    function dfs(u: string) {
      visited[u] = true;
      disc[u] = low[u] = ++time;
      let children = 0;

      for (let v of graph[u]) {
        if (!visited[v]) {
          children++;
          parent[v] = u;
          dfs(v);
          low[u] = Math.min(low[u], low[v]);
          if (parent[u] === undefined && children > 1) ap.add(u);
          if (parent[u] !== undefined && low[v] >= disc[u]) ap.add(u);
        } else if (v !== parent[u]) {
          low[u] = Math.min(low[u], disc[v]);
        }
      }
    }

    for (let node in graph) {
      if (!visited[node]) dfs(node);
    }

    return Array.from(ap);
  };

  const analyzeNetwork = () => {
    if (networkData.length === 0) {
      toast({
        title: "Error",
        description: "Please upload a file first.",
        variant: "destructive",
      });
      return;
    }

    const graph = buildGraph(networkData);
    const spofs = findArticulationPoints(graph);
    setCurrentSPOFs(spofs);

    // Generate statistics
    const totalNodes = Object.keys(graph).length;
    const spofCount = spofs.length;
    const percentage = ((spofCount / totalNodes) * 100).toFixed(2);
    
    setStats({
      totalNodes,
      spofCount,
      percentage
    });

    // Prepare for visualization
    const nodes = Object.keys(graph).map(id => ({ id }));
    const links: Link[] = [];

    for (let source in graph) {
      for (let target of graph[source]) {
        if (source < target) links.push({ source, target });
      }
    }

    setAllNodes(nodes);
    setAllLinks(links);

    // Draw the graph
    drawGraph(nodes, links, spofs);
  };

  const drawGraph = (nodes: Node[], links: Link[], spofs: string[]) => {
    if (!svgRef.current) return;
    
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();
    
    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;
    const g = svg.append("g");

    // Add zoom functionality
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 3])
      .on("zoom", (event) => g.attr("transform", event.transform));
    
    svg.call(zoom as any);

    // Create force simulation
    const simulation = d3.forceSimulation<Node>(nodes)
      .force("link", d3.forceLink<Node, Link>(links).id(d => d.id).distance(120))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2));
    
    simulationRef.current = simulation;

    // Draw links
    const linkElements = g.append("g")
      .attr("stroke", "#aaa")
      .attr("stroke-width", 1.5)
      .selectAll("line")
      .data(links)
      .join("line");

    // Draw nodes - ensuring node IDs are properly processed
    const nodeElements = g.append("g")
      .attr("stroke", "#fff")
      .attr("stroke-width", 1.5)
      .selectAll("circle")
      .data(nodes)
      .join("circle")
      .attr("r", 15)
      .attr("fill", d => spofs.includes(d.id) ? "#ea384c" : "#4CAF50")
      .attr("id", d => `node-${encodeURIComponent(d.id.replace(/\W/g, '_'))}`)
      .call(drag(simulation) as any);

    // Add labels - also ensuring IDs are properly processed
    const labelElements = g.append("g")
      .selectAll("text")
      .data(nodes)
      .join("text")
      .text(d => d.id)
      .attr("font-size", "12px")
      .attr("dx", 15)
      .attr("dy", 4)
      .attr("id", d => `label-${encodeURIComponent(d.id.replace(/\W/g, '_'))}`);

    // Update positions on tick
    simulation.on("tick", () => {
      linkElements
        .attr("x1", d => (d.source as Node).x || 0)
        .attr("y1", d => (d.source as Node).y || 0)
        .attr("x2", d => (d.target as Node).x || 0)
        .attr("y2", d => (d.target as Node).y || 0);

      nodeElements
        .attr("cx", d => d.x || 0)
        .attr("cy", d => d.y || 0);

      labelElements
        .attr("x", d => d.x || 0)
        .attr("y", d => d.y || 0);
    });
  };

  // Drag functionality for nodes
  const drag = (simulation: d3.Simulation<Node, undefined>) => {
    function dragstarted(event: any, d: Node) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }
    
    function dragged(event: any, d: Node) {
      d.fx = event.x;
      d.fy = event.y;
    }
    
    function dragended(event: any, d: Node) {
      if (!event.active) simulation.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }
    
    return d3.drag<SVGCircleElement, Node>()
      .on("start", dragstarted)
      .on("drag", dragged)
      .on("end", dragended);
  };

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchText(query);
    
    if (!query) {
      setSearchResults([]);
      return;
    }

    // Search using case-insensitive comparison but keep the original node ID for highlighting
    const lowerQuery = query.toLowerCase();
    const matches = allNodes.filter(n => 
      n.id.toLowerCase().includes(lowerQuery)
    );
    
    setSearchResults(matches);
    
    // Log found search results for debugging
    console.log(`Search query: "${query}"`);
    console.log(`Found ${matches.length} matches:`, matches.map(n => n.id));
    
    // If we have an exact match, highlight it immediately
    const exactMatch = allNodes.find(n => n.id.toLowerCase() === lowerQuery);
    if (exactMatch) {
      highlightNode(exactMatch.id);
    }
  };

  const highlightNode = (nodeId: string) => {
    console.log(`Attempting to highlight node: "${nodeId}"`);
    
    if (!svgRef.current) {
      console.log("SVG reference is null");
      return;
    }
    
    // Reset previous highlights
    d3.selectAll(".highlight-node").classed("highlight-node", false);
    d3.selectAll(".highlight-text").classed("highlight-text", false);

    // Use a more reliable method to encode the node ID for selection
    const safeId = encodeURIComponent(nodeId.replace(/\W/g, '_'));
    console.log(`Safe ID for selection: "${safeId}"`);
    
    const nodeSelector = `#node-${safeId}`;
    const labelSelector = `#label-${safeId}`;
    
    console.log(`Looking for node with selector: "${nodeSelector}"`);
    
    const node = d3.select(nodeSelector);
    const label = d3.select(labelSelector);

    if (!node.empty()) {
      console.log("Node found! Applying highlight...");
      
      // Apply highlight classes
      node.classed("highlight-node", true);
      label.classed("highlight-text", true);

      // Find the node data to center the view
      const nodeData = allNodes.find(n => n.id === nodeId);
      
      if (nodeData && nodeData.x && nodeData.y && svgRef.current) {
        // Center the view on the node with smooth transition
        const svg = d3.select(svgRef.current);
        const currentZoom = d3.zoomTransform(svg.node() as any);
        
        svg.transition().duration(750).call(
          d3.zoom<SVGSVGElement, unknown>().transform as any,
          d3.zoomIdentity
            .translate(
              svgRef.current.clientWidth / 2 - (nodeData.x || 0), 
              svgRef.current.clientHeight / 2 - (nodeData.y || 0)
            )
            .scale(currentZoom.k)
        );
      }
      
      // Provide feedback to the user
      toast({
        title: "Node Found",
        description: `Highlighting node: ${nodeId}`,
      });
    } else {
      console.log("Node NOT found!");
      console.log("All nodes:", allNodes.map(n => n.id));
      console.log("All node elements:", Array.from(document.querySelectorAll('circle')).map(el => el.id));
      
      // Try a fallback method - search by node id content
      const allNodeElements = d3.selectAll('circle').data();
      const matchingNode = allNodeElements.find((d: any) => d && d.id === nodeId);
      
      if (matchingNode) {
        console.log("Found node through data matching!");
        const matchIndex = allNodeElements.indexOf(matchingNode);
        const nodeEl = d3.selectAll('circle').nodes()[matchIndex] as any;
        const labelEl = d3.selectAll('text').nodes()[matchIndex] as any;
        
        d3.select(nodeEl).classed("highlight-node", true);
        d3.select(labelEl).classed("highlight-text", true);
        
        toast({
          title: "Node Found",
          description: `Highlighting node: ${nodeId}`,
        });
      } else {
        // Node not found
        toast({
          title: "Node Not Found",
          description: `Could not find node: ${nodeId}`,
          variant: "destructive",
        });
      }
    }
  };

  const exportSPOFs = () => {
    if (currentSPOFs.length === 0) {
      toast({
        title: "No Data",
        description: "Please analyze the network first to generate SPOF data.",
        variant: "destructive",
      });
      return;
    }

    const worksheet = XLSX.utils.aoa_to_sheet([["SPOF Nodes"], ...currentSPOFs.map(n => [n])]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, worksheet, "SPOF Nodes");
    XLSX.writeFile(wb, "spof_nodes.xlsx");
    
    toast({
      title: "Export Successful",
      description: "SPOF data has been exported to Excel.",
    });
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="w-[280px] p-4 bg-card shadow-lg flex flex-col border-r">
        <h1 className="text-xl font-bold mb-4 flex items-center">
          <Network className="mr-2" />
          SPOF Detection Tool
        </h1>
        
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Upload Network Data</label>
          <div className="flex">
            <label className="w-full">
              <div className="flex items-center justify-center w-full h-10 px-4 py-2 text-sm border rounded-md cursor-pointer hover:bg-accent">
                <Upload className="w-4 h-4 mr-2" />
                Choose Excel File
              </div>
              <Input 
                type="file" 
                onChange={handleFile} 
                className="hidden" 
                accept=".xlsx" 
              />
            </label>
          </div>
        </div>
        
        <div className="mb-4 relative">
          <label className="block text-sm font-medium mb-1">Search Nodes</label>
          <div className="flex">
            <Input
              value={searchText}
              onChange={handleSearchInput}
              placeholder="Search node ID..."
              className="w-full"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchText) {
                  highlightNode(searchText);
                  setSearchResults([]);
                }
              }}
            />
            <Button 
              variant="outline" 
              className="ml-2" 
              onClick={() => {
                if (searchText) {
                  highlightNode(searchText);
                  setSearchResults([]);
                }
              }}
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
          
          {searchResults.length > 0 && (
            <div className="absolute z-10 w-full mt-1 bg-card shadow-md rounded-md border max-h-40 overflow-auto">
              {searchResults.map((node) => (
                <div
                  key={node.id}
                  className="p-2 hover:bg-accent cursor-pointer"
                  onClick={() => {
                    setSearchText(node.id);
                    highlightNode(node.id);
                    setSearchResults([]);
                  }}
                >
                  {node.id}
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="space-y-2 mb-4">
          <Button 
            onClick={analyzeNetwork} 
            className="w-full" 
            variant="default"
          >
            <Network className="mr-2 h-4 w-4" />
            Analyze Network
          </Button>
          
          <Button 
            onClick={exportSPOFs} 
            className="w-full" 
            variant="outline"
          >
            <Download className="mr-2 h-4 w-4" />
            Export SPOF List
          </Button>
        </div>
        
        {stats && (
          <div className="p-3 bg-muted rounded-md mb-4">
            <h3 className="font-medium mb-1 flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-amber-500" />
              SPOF Analytics
            </h3>
            <div className="text-sm space-y-1">
              <div>Total Nodes: <span className="font-medium">{stats.totalNodes}</span></div>
              <div>SPOF Count: <span className="font-medium text-destructive">{stats.spofCount}</span></div>
              <div>Percentage: <span className="font-medium">{stats.percentage}%</span></div>
            </div>
          </div>
        )}
        
        <div className="flex-grow bg-muted p-3 rounded-md overflow-y-auto text-sm font-mono">
          <div className="font-medium mb-1">SPOF Results:</div>
          {currentSPOFs.length > 0 ? (
            <div>
              {currentSPOFs.map(spof => (
                <div 
                  key={spof} 
                  className="cursor-pointer hover:bg-accent p-1 rounded"
                  onClick={() => highlightNode(spof)}
                >
                  {spof}
                </div>
              ))}
            </div>
          ) : (
            <div>Upload an Excel file with Source & Target columns and analyze the network to see results.</div>
          )}
        </div>
      </div>
      
      {/* Main visualization area */}
      <div className="flex-1 relative">
        <svg 
          ref={svgRef} 
          className="w-full h-full"
        >
          <style>
            {`
            .highlight-node {
              fill: #0EA5E9 !important;
              stroke: #fff;
              stroke-width: 2px;
            }
            .highlight-text {
              fill: #0EA5E9 !important;
              font-weight: bold;
            }
            `}
          </style>
        </svg>
      </div>
    </div>
  );
};

export default SPOFDetector;
