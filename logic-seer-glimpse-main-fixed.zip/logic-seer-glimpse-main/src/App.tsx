
import { useState } from 'react';
import { Toaster } from "@/components/ui/toaster";
import SPOFDetector from './components/SPOFDetector';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SPOFDetector />
      <Toaster />
    </div>
  );
}

export default App;
